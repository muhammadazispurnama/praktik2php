<?php
    $nama =$_GET['nama'];
    $matkul =$_GET['matkul'];
    $uts =$_GET['uts'];
    $uas =$_GET['uas'];
    $nilai_tugas = $_GET['tugas'];

    echo 'NAMA Mahasiswa :'. $nama;
    echo '<br> Mata Kuliah:'. $matkul;
    echo '<br> Nilai UTS:'. $uts;
    echo '<br> Nilai UAS:'. $uas;
    echo '<br> Nilai Tugas:'. $nilai_tugas;




?>