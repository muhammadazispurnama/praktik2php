<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-8">
            <form method="POST" action="">
  <div class="form-group row">
    <label for="produk" class="col-4 col-form-label">customer</label> 
    <div class="col-8">
      <input id="nama" name="nama" type="text" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label class="col-4">produk</label> 
    <div class="col-8">
      <div class="custom-control custom-radio custom-control-inline">
        <input name="produk" id="_0" type="radio" class="custom-control-input" value="tv"> 
        <label for="_0" class="custom-control-label">tv</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="" id="_1" type="radio" class="custom-control-input" value="kulkas"> 
        <label for="_1" class="custom-control-label">kulkas</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="" id="_2" type="radio" class="custom-control-input" value="mesin cuci"> 
        <label for="_2" class="custom-control-label">mesin cuci</label>
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="text" class="col-4 col-form-label">jumlah</label> 
    <div class="col-8">
      <input id="jumlah" name="jumlah" type="text" class="form-control">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
</form>
            </div>

            <div class="col-4">
            <ul class="list-group">
                <li class="list-group-item active" aria-current="true">Dagtar harga</li>
                <li class="list-group-item">tv : 4.200.000</li>
                <li class="list-group-item">kulkas : 3.100.00</li>
                <li class="list-group-item">mesin cuci : 3.800.000</li>
                <li class="list-group-item active" aria-current="true">harga dapat berubah sewaktu waktu</li>
            </ul>

            </div>
        </div>
    </div>

    <hr>

    <?php if(isset($_POST['submit'])) : ?>

        Nama customer : <?= $_POST['nama']?>
        <br>
        produk :       <?= $_POST['produk']?>
        <br>
        jumlah :       <?= $_POST['jumlah']?>


        <?php
           
           if(  $_POST['produk'] == "tv" && $_POST['jumlah'] >= 1 ){
                 $harga = 4200000 * $_POST['jumlah'];
                 echo' TOTAL HARGA : '.$harga;
           } elseif ( $_POST['produk']== "kulkas" && $_POST['jumlah'] >= 1){
            $harga = 3100000 * $_POST['jumlah'];
            echo' TOTAL HARGA : '.$harga;
           } elseif  ($_POST['produk']== "mesin cuci" && $_POST['jumlah'] >= 1){
            $harga = 3800000 * $_POST['jumlah'];
            echo' TOTAL HARGA : '.$harga;
           }
           ?>


    <?php endif  ?>


    

</body>
</html>